package com.example.demo.ResultClass;

public class ReturnResult {

    public static Result sucess(Integer a,String b){
        return new Result(String.format("No.%d is %s",a,b));
    }

    public static Result fail(Integer err_code, String err_msg){
        return new Result(err_code, err_msg);
    }

    public static Result fail(Error_Code error_code){
        return fail(error_code.getErr_code(),error_code.getErr_msg());
    }

}
