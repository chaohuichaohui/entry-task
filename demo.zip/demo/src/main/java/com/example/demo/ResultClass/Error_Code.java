package com.example.demo.ResultClass;

public enum Error_Code {

    SSUCCESS(0,"sucess"),
    SYSTEM_ERR(11,"system error"),
    PARAMS_ERR(21,"empry or wrong params"),
    ;

    private Integer err_code;

    private String err_msg;

    public int getErr_code() {
        return err_code;
    }

    public String getErr_msg() {
        return err_msg;
    }

    Error_Code(Integer err_code, String err_msg) {
        this.err_code = err_code;
        this.err_msg = err_msg;
    }
}
