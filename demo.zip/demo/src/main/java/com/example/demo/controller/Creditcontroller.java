package com.example.demo.controller;

import com.example.demo.MyException.MyException;
import com.example.demo.ParamClass.Praramclass;
import com.example.demo.ResultClass.Result;
import com.example.demo.ResultClass.ReturnResult;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/shopee")
public class Creditcontroller {


    @GetMapping("/test")
    @ResponseBody
    public Result getCreditcode( @Valid Praramclass praramclass, BindingResult bindingResult) throws Exception {
        if (bindingResult.hasErrors()){
            throw new MyException(21,"empry or wrong params");
        }
        else if(praramclass.getA()==100)
            throw new Exception("abc");
            return ReturnResult.sucess(praramclass.getA(),praramclass.getB());
    }
}
