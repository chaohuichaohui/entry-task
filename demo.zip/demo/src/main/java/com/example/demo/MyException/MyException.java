package com.example.demo.MyException;

import com.example.demo.ResultClass.Error_Code;

public class MyException extends RuntimeException {
    private Integer err_code;

    private String err_msg;

    public Integer getErr_code() {
        return err_code;
    }

    public String getErr_message() {
        return err_msg;
    }

    public MyException(Integer error_code, String error_message) {
        this.err_code = error_code;
        this.err_msg = error_message;
    }

    public MyException(Error_Code error_code){
        this.err_code=error_code.getErr_code();
        this.err_msg=error_code.getErr_msg();
    }
}
