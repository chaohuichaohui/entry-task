package com.example.demo.ParamClass;


import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.*;

public class Praramclass {

    @NotNull
    private Integer a;

    @NotBlank
    @Length(max = 200)
    private String b;

    public Praramclass(Integer a, String b) {
        this.a = a;
        this.b = b;
    }

    public Praramclass() {
    }

    public void setA(Integer a) {
        this.a = a;
    }

    public void setB(String b) {
        this.b = b;
    }

    public Integer getA() {
        return a;
    }

    public String getB() {
        return b;
    }
}
