package com.example.demo.ResultClass;

public class Result {
    private Integer err_code;

    private String err_msg;

    public void setErr_code(Integer err_code) {
        this.err_code = err_code;
    }

    public void setErr_msg(String err_msg) {
        this.err_msg = err_msg;
    }

    public void setRefenence(String refenence) {
        this.refenence = refenence;
    }

    public Integer getErr_code() {
        return err_code;
    }

    public String getErr_msg() {
        return err_msg;
    }

    public String getRefenence() {
        return refenence;
    }

    private String refenence;

    public Result(String refenence) {
        this(0, "success");
        this.refenence = refenence;
    }

    public Result(Integer err_code, String err_msg) {
        this.err_code = err_code;
        this.err_msg = err_msg;
    }
}
