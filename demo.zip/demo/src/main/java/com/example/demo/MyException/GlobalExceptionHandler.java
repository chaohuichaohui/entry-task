package com.example.demo.MyException;

import com.example.demo.ResultClass.Error_Code;
import com.example.demo.ResultClass.Result;
import com.example.demo.ResultClass.ReturnResult;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(value = MyException.class)
    @ResponseBody
    public Result myExceptionHandler(HttpServletRequest req){
        return ReturnResult.fail(Error_Code.PARAMS_ERR);
    }

    @ExceptionHandler(value =Exception.class)
    @ResponseBody
    public Result ExceptionHandler(HttpServletRequest request,Exception e){
        return ReturnResult.fail(Error_Code.SYSTEM_ERR);
    }


}
